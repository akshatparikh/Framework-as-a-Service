package com.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.DAO.*;
import com.VO.*;

@Controller
public class kjkjkjController{

	@Autowired
	KjkjkjDAO kjkjkjDAO;

	@RequestMapping(value="loadkjkjkj.html", method=RequestMethod.GET)
	public ModelAndView loadkjkjkj()
	{
		return new ModelAndView("kjkjkj","KjkjkjVO",new KjkjkjVO());
	}

	@RequestMapping(value="insertkjkjkj.html", method=RequestMethod.GET)
	public ModelAndView insertkjkjkj(@ModelAttribute KjkjkjVO kjkjkjVO)
	{
		this.kjkjkjDAO.insert(kjkjkjVO);
		return new ModelAndView("redirect:searchkjkjkj.html");
	}

	@RequestMapping(value="searchkjkjkj.html", method=RequestMethod.GET)
	public ModelAndView searchkjkjkj(@ModelAttribute KjkjkjVO kjkjkjVO)
	{
		List ls = this.kjkjkjDAO.search();
		return new ModelAndView("kjkjkjSearch","list",ls);
	}

	@RequestMapping(value="deletekjkjkj.html",method=RequestMethod.GET)
	public ModelAndView deletekjkjkj(@ModelAttribute KjkjkjVO kjkjkjVO, @RequestParam String id )
	{
		kjkjkjVO.setKjkjkjId (Integer.parseInt(id));
		this.kjkjkjDAO.delete(kjkjkjVO);
		return new ModelAndView("redirect:searchkjkjkj.html");
	}

	@RequestMapping(value="editkjkjkj.html",method=RequestMethod.GET)
	public ModelAndView editkjkjkj(@ModelAttribute KjkjkjVO kjkjkjVO, @RequestParam String id)
	{
		kjkjkjVO.setKjkjkjId (Integer.parseInt(id));
		List ls = this.kjkjkjDAO.edit(kjkjkjVO);
		KjkjkjVO kjkjkjVO2 = (KjkjkjVO)ls.get(0);
		return new ModelAndView("kjkjkj","KjkjkjVO",kjkjkjVO2);
	}
}