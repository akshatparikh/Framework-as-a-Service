package com.VO;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name="kjkjkj_Table")
public class KjkjkjVO{ 

	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO) 
@Column(name="kjkjkjId")	private int kjkjkjId;

	public int getKjkjkjId()  {
		return kjkjkjId ;
	}

	public void setKjkjkjId (int kjkjkjId) {
		this.kjkjkjId = kjkjkjId;
	}

@Column(name="imageId")	private String image;

	public String getImage(){
		return image;
	}

	public void setImage(String image) {
		this.image=image;
	}

	}