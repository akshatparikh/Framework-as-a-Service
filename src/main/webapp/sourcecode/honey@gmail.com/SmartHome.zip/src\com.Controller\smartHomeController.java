package com.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.DAO;
import com.VO;

@Controller
public class smartHomeController{

	@Autowired
	SmartHomeDAO smartHomeDAO;

	@RequestMapping(value="loadsmartHome.html", method=RequestMethod.GET)
	public ModelAndView loadsmartHome()
	{
		return new ModelAndView("smartHome","SmartHomeVO",new SmartHomeVO());
	}

	@RequestMapping(value="insertsmartHome.html", method=RequestMethod.GET)
	public ModelAndView insertsmartHome(@ModelAttribute SmartHomeVO smartHomeVO)
	{
		this.smartHomeDAO.insert(smartHomeVO);
		return new ModelAndView("redirect:searchsmartHome.html");
	}

	@RequestMapping(value="searchsmartHome.html", method=RequestMethod.GET)
	public ModelAndView searchsmartHome(@ModelAttribute SmartHomeVO smartHomeVO)
	{
		List ls = this.smartHomeDAO.search();
		return new ModelAndView("smartHomeSearch","list",ls);
	}

	@RequestMapping(value="deletesmartHome.html",method=RequestMethod.GET)
	public ModelAndView deletesmartHome(@ModelAttribute SmartHomeVO smartHomeVO, @RequestParam String id )
	{
		smartHomeVO.setSmartHomeId (Integer.parseInt(id));
		this.smartHomeDAO.delete(smartHomeVO);
		return new ModelAndView("redirect:searchsmartHome.html");
	}

	@RequestMapping(value="editsmartHome.html",method=RequestMethod.GET)
	public ModelAndView editsmartHome(@ModelAttribute SmartHomeVO smartHomeVO, @RequestParam String id)
	{
		smartHomeVO.setSmartHomeId (Integer.parseInt(id));
		List ls = this.smartHomeDAO.edit(smartHomeVO);
		SmartHomeVO smartHomeVO2 = (SmartHomeVO)ls.get(0);
		return new ModelAndView("smartHome","SmartHomeVO",smartHomeVO2);
	}
}