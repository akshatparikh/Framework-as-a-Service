package com.VO;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name="smartHome_Table")
public class SmartHomeVO{ 

	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO) 
	private int smartHomeId;

	public int getSmartHomeId()  {
		return smartHomeId ;
	}

	public void setSmartHomeId (int smartHomeId) {
		this.smartHomeId = smartHomeId;
	}

	private String gender;

	public String getGender(){
		return gender;
	}

	public void setGender(String gender) {
		this.gender=gender;
	}

	private String fname;

	public String getFname(){
		return fname;
	}

	public void setFname(String fname) {
		this.fname=fname;
	}

	}