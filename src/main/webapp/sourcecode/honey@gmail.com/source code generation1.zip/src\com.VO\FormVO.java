package com.VO;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name="form_Table")
public class FormVO{ 

	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO) 
	private int formId;

	public int getFormId()  {
		return formId ;
	}

	public void setFormId (int formId) {
		this.formId = formId;
	}

	private String firstName;

	public String getFirstName(){
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName=firstName;
	}

	private String Address;

	public String getAddress(){
		return Address;
	}

	public void setAddress(String Address) {
		this.Address=Address;
	}

	private String Gender;

	public String getGender(){
		return Gender;
	}

	public void setGender(String Gender) {
		this.Gender=Gender;
	}

	}