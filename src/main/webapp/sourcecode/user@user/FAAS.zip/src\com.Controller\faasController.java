package com.Controller;

import java.util.List;import org.springframework.beans.factory.annotation.Autowired;import org.springframework.stereotype.Controller;import org.springframework.web.bind.annotation.ModelAttribute;import org.springframework.web.bind.annotation.RequestMapping;import org.springframework.web.bind.annotation.RequestMethod;import org.springframework.web.bind.annotation.RequestParam;import org.springframework.web.servlet.ModelAndView;import com.DAO.*import com.VO.*@Controller
public class faasController{

	@Autowired
	FaasDAO faasDAO;

	@RequestMapping(value="loadfaas.html", method=RequestMethod.GET)
	public ModelAndView loadfaas()
	{
		return new ModelAndView("faas","FaasVO",new FaasVO());
	}

	@RequestMapping(value="insertfaas.html", method=RequestMethod.GET)
	public ModelAndView insertfaas(@ModelAttribute FaasVO faasVO)
	{
		this.faasDAO.insert(faasVO);
		return new ModelAndView("redirect:searchfaas.html");
	}

	@RequestMapping(value="searchfaas.html", method=RequestMethod.GET)
	public ModelAndView searchfaas(@ModelAttribute FaasVO faasVO)
	{
		List ls = this.faasDAO.search();
		return new ModelAndView("faasSearch","list",ls);
	}

	@RequestMapping(value="deletefaas.html",method=RequestMethod.GET)
	public ModelAndView deletefaas(@ModelAttribute FaasVO faasVO, @RequestParam String id )
	{
		faasVO.setFaasId (Integer.parseInt(id));
		this.faasDAO.delete(faasVO);
		return new ModelAndView("redirect:searchfaas.html");
	}

	@RequestMapping(value="editfaas.html",method=RequestMethod.GET)
	public ModelAndView editfaas(@ModelAttribute FaasVO faasVO, @RequestParam String id)
	{
		faasVO.setFaasId (Integer.parseInt(id));
		List ls = this.faasDAO.edit(faasVO);
		FaasVO faasVO2 = (FaasVO)ls.get(0);
		return new ModelAndView("faas","FaasVO",faasVO2);
	}
}