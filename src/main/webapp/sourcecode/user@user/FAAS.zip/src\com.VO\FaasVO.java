package com.VO;

import javax.persistence.Entity;import javax.persistence.GeneratedValue;import javax.persistence.GenerationType;import javax.persistence.Id;import javax.persistence.Table;@Entity 
@Table(name="faas_Table")
public class FaasVO{ 

	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO) 
	private int faasId;

	public int getFaasId()  {
		return faasId ;
	}

	public void setFaasId (int faasId) {
		this.faasId = faasId;
	}

	private String fname;

	public String getFname(){
		return fname;
	}

	public void setFname(String fname) {
		this.fname=fname;
	}

	}