package com.Controller;

import java.util.List;import org.springframework.beans.factory.annotation.Autowired;import org.springframework.stereotype.Controller;import org.springframework.web.bind.annotation.ModelAttribute;import org.springframework.web.bind.annotation.RequestMapping;import org.springframework.web.bind.annotation.RequestMethod;import org.springframework.web.bind.annotation.RequestParam;import org.springframework.web.servlet.ModelAndView;import com.DAO.*import com.VO.*@Controller
public class aaController{

	@Autowired
	AaDAO aaDAO;

	@RequestMapping(value="loadaa.html", method=RequestMethod.GET)
	public ModelAndView loadaa()
	{
		return new ModelAndView("aa","AaVO",new AaVO());
	}

	@RequestMapping(value="insertaa.html", method=RequestMethod.GET)
	public ModelAndView insertaa(@ModelAttribute AaVO aaVO)
	{
		this.aaDAO.insert(aaVO);
		return new ModelAndView("redirect:searchaa.html");
	}

	@RequestMapping(value="searchaa.html", method=RequestMethod.GET)
	public ModelAndView searchaa(@ModelAttribute AaVO aaVO)
	{
		List ls = this.aaDAO.search();
		return new ModelAndView("aaSearch","list",ls);
	}

	@RequestMapping(value="deleteaa.html",method=RequestMethod.GET)
	public ModelAndView deleteaa(@ModelAttribute AaVO aaVO, @RequestParam String id )
	{
		aaVO.setAaId (Integer.parseInt(id));
		this.aaDAO.delete(aaVO);
		return new ModelAndView("redirect:searchaa.html");
	}

	@RequestMapping(value="editaa.html",method=RequestMethod.GET)
	public ModelAndView editaa(@ModelAttribute AaVO aaVO, @RequestParam String id)
	{
		aaVO.setAaId (Integer.parseInt(id));
		List ls = this.aaDAO.edit(aaVO);
		AaVO aaVO2 = (AaVO)ls.get(0);
		return new ModelAndView("aa","AaVO",aaVO2);
	}
}