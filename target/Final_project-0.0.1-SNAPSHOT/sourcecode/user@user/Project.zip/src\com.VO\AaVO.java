package com.VO;

import javax.persistence.Entity;import javax.persistence.GeneratedValue;import javax.persistence.GenerationType;import javax.persistence.Id;import javax.persistence.Table;@Entity 
@Table(name="aa_Table")
public class AaVO{ 

	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO) 
	private int aaId;

	public int getAaId()  {
		return aaId ;
	}

	public void setAaId (int aaId) {
		this.aaId = aaId;
	}

	private String fname;

	public String getFname(){
		return fname;
	}

	public void setFname(String fname) {
		this.fname=fname;
	}

	}