package com.Controller;

@Controller
public class registrationController{

	@Autowired
	RegistrationDAO registrationDAO;

	@RequestMapping(value="loadregistration.html", method=RequestMethod.GET)
	public ModelAndView loadregistration()
	{
		return new ModelAndView("registration","RegistrationVO",new RegistrationVO());
	}

	@RequestMapping(value="insertregistration.html", method=RequestMethod.GET)
	public ModelAndView insertregistration(@ModelAttribute RegistrationVO registrationVO)
	{
		this.registrationDAO.insert(registrationVO);
		return new ModelAndView("redirect:searchregistration.html");
	}

	@RequestMapping(value="searchregistration.html", method=RequestMethod.GET)
	public ModelAndView searchregistration(@ModelAttribute RegistrationVO registrationVO)
	{
		List ls = this.registrationDAO.search();
		return new ModelAndView("registrationSearch","list",ls);
	}

	@RequestMapping(value="deleteregistration.html",method=RequestMethod.GET)
	public ModelAndView deleteregistration(@ModelAttribute RegistrationVO registrationVO, @RequestParam String id )
	{
		registrationVO.setRegistrationId (Integer.parseInt(id));
		this.registrationDAO.delete(registrationVO);
		return new ModelAndView("redirect:searchregistration.html");
	}

	@RequestMapping(value="editregistration.html",method=RequestMethod.GET)
	public ModelAndView editregistration(@ModelAttribute RegistrationVO registrationVO, @RequestParam String id)
	{
		registrationVO.setRegistrationId (Integer.parseInt(id));
		List ls = this.registrationDAO.edit(registrationVO);
		RegistrationVO registrationVO2 = (RegistrationVO)ls.get(0);
		return new ModelAndView("registration","RegistrationVO",registrationVO2);
	}
}