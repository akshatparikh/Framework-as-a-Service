package com.VO;

@Entity 
@Table(name="registration_Table")
public class RegistrationVO{ 

	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO) 
	private int registrationId;

	public int getRegistrationId()  {
		return registrationId ;
	}

	public void setRegistrationId (int registrationId) {
		this.registrationId = registrationId;
	}

	private String firstName;

	public String getFirstName(){
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName=firstName;
	}

	private String lastName;

	public String getLastName(){
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName=lastName;
	}

	private String userName;

	public String getUserName(){
		return userName;
	}

	public void setUserName(String userName) {
		this.userName=userName;
	}

	private String password;

	public String getPassword(){
		return password;
	}

	public void setPassword(String password) {
		this.password=password;
	}

	}